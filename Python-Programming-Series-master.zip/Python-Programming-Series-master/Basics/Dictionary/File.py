dictionary = {}
dictionary[1] = "Item 1"
dictionary[2] = "Item 2"
dictionary["Hello"] = "Item 3"

print(dictionary[1])
print(dictionary[2])
print(dictionary["Hello"])
print(dictionary)
print(dictionary.values())
print(dictionary.keys())

newDictionary = {1:"Item 1", 2:"Item 2", "Hello":"Item 3"}

print(newDictionary)