# cook your dish here

var1 = True
var2 = True
var3 = False
var4 = False

# AND Logical Operator
print("AND Logical Operator")
print(var1 and var2)
print(var1 and var3)
print(var3 and var4)

# OR Logical Operator
print("OR Logical Operator")
print(var1 or var2)
print(var1 or var3)
print(var3 or var4)

# NOT Logical Operator
print("NOT Logical Operator")
print(not(var1))
print(not(var3))