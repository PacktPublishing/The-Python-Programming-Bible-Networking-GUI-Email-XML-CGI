if (500 == 500):
    print("Yes")

if (500 == 500):
    print("Yes")
else:
    print("No")
    
if (400 == 500):
    print("Yes")
else:
    print("No")
    
    
var1 = 100

if (var1 == 500):
    print("Var1 is equal to 500")
elif (var1 == 400):
    print("Var1 is equal to 400")
elif (var1 == 300):
    print("Var1 is equal to 300")
elif (var1 == 200):
    print("Var1 is equal to 200")
else:
    print("No it doesn't equal a valid value")
    
if (var1 > 50):print("Var1 is greater than 50")
    