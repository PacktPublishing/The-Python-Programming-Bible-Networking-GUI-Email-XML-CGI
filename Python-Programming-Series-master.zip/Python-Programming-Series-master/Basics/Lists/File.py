awesomeList = ['Hello', 45, 'World', 4.5]

print(awesomeList)
print(awesomeList[0])
print(awesomeList[3])
print(awesomeList[0:2])