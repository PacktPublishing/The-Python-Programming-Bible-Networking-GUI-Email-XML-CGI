var1 = 6.7

print(var1)
print(int(var1))