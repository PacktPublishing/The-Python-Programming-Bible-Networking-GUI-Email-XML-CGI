string1 = "Python is amazing"

print(string1)
print(string1[1])
print(string1[1:4])

print(string1[:4] + " Bob")

string2 = "Python is the best"

print("Hello \n World")

string3 = string1 + " " + string2

print(string3)

var1 = "Hello"
var2 = "World"

print("%s this is the best %s" % (var1, var2))

lorem = """Lorem ipsum dolor sit amet, 
consectetur adipiscing elit, sed do eiusmod 
tempor incididunt ut labore et dolore magna aliqua. 
Ut enim ad minim veniam, quis nostrud exercitation ullamco 
laboris nisi ut aliquip ex ea commodo consequat. 
Duis aute irure dolor in reprehenderit in voluptate 
velit esse cillum dolore eu fugiat nulla pariatur. 
Excepteur sint occaecat cupidatat non proident, 
sunt in culpa qui officia deserunt mollit anim id est laborum.
"""

print(lorem)

var4 = "hello World"

print(var4.capitalize())