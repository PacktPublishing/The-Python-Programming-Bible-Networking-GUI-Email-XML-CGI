var1 = 10
var2 = 10
var3 = 8

# IS Operator
print(var1 is var2)
print(var1 is var3)

# IS NOT Operator
print(var1 is not var2)
print(var1 is not var3)