var1 = 6 + 7
print(var1)

var1 = var1 + 5
print(var1)

var1 += 5
print(var1)