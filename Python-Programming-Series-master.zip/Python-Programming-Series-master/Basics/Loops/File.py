var1 = "Hello World"
var2 = 110

for character in var1:
    print(character)
    
while (var2 < 110):
    print("Less than 110")
    var2 += 1
else:
    print("Not less than 110")