# cook your dish here

# This line prints 5
print(5)