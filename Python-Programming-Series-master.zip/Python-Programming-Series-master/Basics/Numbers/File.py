import math

num1 = 5

print(math.exp(5))

print(math.sqrt(5))

print(math.sin(math.pi/2))