var1 = 500
var2 = 45.68
var3 = "Hello World"

a = b = c = 7

print(a)
print(b)
print(c)

print(var3)
print(var3[0])
print(var3[0:4])
print(var3[1:])