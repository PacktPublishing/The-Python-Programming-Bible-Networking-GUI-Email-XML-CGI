string1 = "Hello World"

print('H' in string1)
print('Z' in string1)

print('H' not in string1)
print('Z' not in string1)