print(5 + 6)
print(5 - 6)
print(5 * 6)
print(5 / 6)

print(5 % 6)
print(9 % 4)

print(5**2)

print(17//3)