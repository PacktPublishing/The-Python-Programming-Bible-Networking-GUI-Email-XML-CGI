# Importing/Including a module
import math

# Specific module functionality importer
# from math import pi

print(math.pi)

contents = dir(math)
print(contents)