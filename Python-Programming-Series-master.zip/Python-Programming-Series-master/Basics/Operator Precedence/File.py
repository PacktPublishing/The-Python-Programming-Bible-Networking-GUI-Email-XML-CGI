var1 = 5 ** 2 + 7
var2 = 5 + 7 ** 2

print(var1)
print(var2)