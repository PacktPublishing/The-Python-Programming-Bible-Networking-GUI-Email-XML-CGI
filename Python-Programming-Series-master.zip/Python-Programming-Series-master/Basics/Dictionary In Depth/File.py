# Creating Dictionaries
dictionary1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4 }

# Accessing Values
print(dictionary1)
print(dictionary1['a'])

# Updating Values
dictionary1['a'] = "Hello world"
print(dictionary1['a'])

# Deleting Values
del dictionary1['a']
print(dictionary1)

# Delete Entire Dictionary
#dictionary1.clear()
#del dictionary1

print(len(dictionary1))