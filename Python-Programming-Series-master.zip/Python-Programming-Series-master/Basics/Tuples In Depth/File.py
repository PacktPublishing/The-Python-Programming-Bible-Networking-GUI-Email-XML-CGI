# Creating Tuples
tuple1 = (1, 2, 3, "a", "b", "c")

# Accessing Tuples
print(tuple1)
print(tuple1[1])
print(tuple1[0:4])

# Tuple Operations
print(len(tuple1))

# Deleting Tuples
del tuple1
print(tuple1)

