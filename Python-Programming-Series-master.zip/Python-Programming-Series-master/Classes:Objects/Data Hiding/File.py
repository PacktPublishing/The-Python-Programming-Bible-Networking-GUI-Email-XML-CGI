class Vehicle:
    __speed = 0

    def __init__(self, speed = 0):
      self.__speed = speed

car1 = Vehicle(5)
#print(car1.__speed)
print(car1._Vehicle__speed)