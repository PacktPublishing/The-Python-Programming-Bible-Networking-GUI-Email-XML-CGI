class Vehicle:
    speed = 0
    
    def IncreaseSpeed(self, increaseAmount):
        self.speed += increaseAmount
        
car1 = Vehicle()
car2 = Vehicle()