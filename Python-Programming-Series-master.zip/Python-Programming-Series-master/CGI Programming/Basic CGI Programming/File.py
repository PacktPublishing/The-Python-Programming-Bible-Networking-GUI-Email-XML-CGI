#!/usr/bin/python

print ("Content-type:text/html\r\n\r\n")

print ("<html>")
print ("<head>")
print ("<title>My First CGI-Program </title>")
print ("<head>")
print ("<body>")
print ("<h3>This is HTML's Body section </h3>")
print ("</body>")
print ("</html>")
