#!/usr/bin/python3

import tkinter
from tkinter import *

window = Tk()
window.title("Master")

topL = Toplevel()
topL.title("Child")
topL.mainloop()
