#!/usr/bin/python3

import tkinter
window = tkinter.Tk()



window.mainloop()
